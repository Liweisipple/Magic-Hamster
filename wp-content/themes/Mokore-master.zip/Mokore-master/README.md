﻿![](http://img0.dfjcx.cn/2018/11/timg.jpg)

一个Wordpress二次元个人博客主题，简约而不简单，Made BY 江程训。

最近总感觉作为一个Wordpress老玩家（其实也不算多老，也就接触这个网站程序一年），自己似乎少了点什么，于是就做了这款主题。

本主题从2018年10月月初开始动工，这里有我的心血，希望大家喜欢，也希望大家能够在Github去Star这个主题。

# 主题信息

-   主题名称：Mokore
-   主题作者：[江程训（CensuJiang）](https://dfjcx.cn/)
-   当前版本：1.0.0（2018-11-24）
-   主题类型：WordPress的，个人博客，博客主题，二次元，自媒体，大佬必备
-   特色描述：简约而不简单，特别适合喜欢二次元的自媒体、程序员和画师
-   兼容环境：**PHP5.6.0 +**，WordPress 4.8+
-   官方演示：[https://mokore.dfjcx.cn/](https://mokore.dfjcx.cn/)
-   主题QQ群： [_346363551_](http://shang.qq.com/wpa/qunwpa?idkey=d99e5a83cbba65cd3054bd38b0c9b6bb8cc524b32d269ccb5d67e6d46723f569)
-   主题状态：更新中
-   GIthub下载：[https](https://github.com/censujiang/Mokore)：[//github.com/censujiang/Mokore](https://github.com/censujiang/Mokore)

# 预览图

![](http://img0.dfjcx.cn/2018/11/%E5%B1%8F%E5%B9%95%E6%88%AA%E5%9B%BE196.png)

![](http://img0.dfjcx.cn/2018/11/%E5%B1%8F%E5%B9%95%E6%88%AA%E5%9B%BE197.png)![](http://img0.dfjcx.cn/2018/11/%E5%B1%8F%E5%B9%95%E6%88%AA%E5%9B%BE198.png)![](http://img0.dfjcx.cn/2018/11/%E5%B1%8F%E5%B9%95%E6%88%AA%E5%9B%BE199.png)![](http://img0.dfjcx.cn/2018/11/%E5%B1%8F%E5%B9%95%E6%88%AA%E5%9B%BE200.png)

# 主题描述

如果您正在寻找一款既简单却不简约，既丰富却不复杂，不仅个性而且另类的WordPress 主题。如果这个页面荣幸地被您访问到，那么这款主题极有可能是您的“一生中最爱”。

这款主题是我江程训人生中的第一个Wordpress作品，我会持续更新，本主题在编写过程中引用了一些代码或程序亦或是其他的东西，详情请见[Copyright界面](https://mokore.dfjcx.cn/copyright)。

# 使用中遇到问题？

欢迎在[官方 QQ 交流群](http://shang.qq.com/wpa/qunwpa?idkey=d99e5a83cbba65cd3054bd38b0c9b6bb8cc524b32d269ccb5d67e6d46723f569)中与小伙伴们交流.。

# 下载主题

Github地址：[https://github.com/censujiang/Mokore](https://github.com/censujiang/Mokore)

WordPress官方下载：正在提交审核中，请稍后再看

**非常感谢您选择江程训的Mokore主题，我会持续更新，也希望您把此作品推荐给其他站长或者博主。**